<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://ghrix.com
 * @since             1.0.0
 * @package           Recipes_With_Nutrition
 *
 * @wordpress-plugin
 * Plugin Name:       Recipes with Nutrition
 * Plugin URI:        https://ghrix.com
 * Description:       A plugin for food bloggers and nutritionists to create, manage, and display recipes with detailed nutrition information.
 * Version:           1.0.0
 * Author:            Ghrix Technologies
 * Author URI:        https://ghrix.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       recipes-with-nutrition
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'RECIPES_WITH_NUTRITION_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-recipes-with-nutrition-activator.php
 */
function activate_recipes_with_nutrition() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-recipes-with-nutrition-activator.php';
	Recipes_With_Nutrition_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-recipes-with-nutrition-deactivator.php
 */
function deactivate_recipes_with_nutrition() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-recipes-with-nutrition-deactivator.php';
	Recipes_With_Nutrition_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_recipes_with_nutrition' );
register_deactivation_hook( __FILE__, 'deactivate_recipes_with_nutrition' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-recipes-with-nutrition.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_recipes_with_nutrition() {

	$plugin = new Recipes_With_Nutrition();
	$plugin->run();

}
run_recipes_with_nutrition();

// Initialize the plugin
add_action( 'plugins_loaded', array( 'Recipes_With_Nutrition', 'get_instance' ) );

// Add filters to override templates for 'recipe' post type
add_filter( 'single_template', 'override_template_for_recipe' );
add_filter( 'archive_template', 'override_template_for_recipe' );

function override_template_for_recipe( $template ) {
    global $post;

    if ( is_singular( 'recipe' ) ) {
        $single_template = plugin_dir_path( __FILE__ ) . 'single-recipe.php';
        if ( file_exists( $single_template ) ) {
            return $single_template;
        }
    }

    if ( is_post_type_archive( 'recipe' ) ) {
        $archive_template = plugin_dir_path( __FILE__ ) . 'archive-recipe.php';
        if ( file_exists( $archive_template ) ) {
            return $archive_template;
        }
    }

    return $template;
}
