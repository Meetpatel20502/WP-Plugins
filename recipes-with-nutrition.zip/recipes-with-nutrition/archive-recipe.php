<?php
/**
 * Template Name: Recipe Archive
 */
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php
        $title = "Recipes";
        $site_name = get_bloginfo('name');
        $page_title = $title . ' - ' . $site_name;
        ?>
        <title><?php echo $page_title; ?></title>
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <?php wp_body_open(); ?>
        <div class="wp-site-blocks">
            <header class="wp-block-template-part">
                <?php block_header_area(); ?>
            </header>
            
            <?php if ( have_posts() ) : ?>

                <div class="recipe-archive-container">
                    <h1 class="archive-title"><?php post_type_archive_title(); ?></h1>
                    <div class="recipe-archive-grid">
                        <?php while ( have_posts() ) : the_post(); ?>
                            <div class="recipe-archive-item">
                                <a href="<?php the_permalink(); ?>">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <div class="recipe-archive-thumbnail">
                                            <?php the_post_thumbnail('medium'); ?>
                                        </div>
                                    <?php endif; ?>
                                    <h2 class="recipe-archive-title"><?php the_title(); ?></h2>
                                </a>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
                <?php else : ?>
                    <div class="recipe-archive-container">
                        <p><?php _e( 'No recipes found.', 'text_domain' ); ?></p>
                    </div>
                <?php endif; ?>


            <footer class="wp-block-template-part site-footer">
                <?php block_footer_area(); ?>
            </footer>
        </div>
        <?php wp_footer(); ?>
    </body>
</html>
