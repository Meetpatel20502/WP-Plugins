<?php
/**
 * Template Name: Recipe Single
 */
?>

<!DOCTYPE html>
<html lang="en" <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
        $title = get_the_title();
        $site_name = get_bloginfo('name');
        $page_title = $title . ' - ' . $site_name;
    ?>
    <title><?php echo $page_title; ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

    <header class="wp-block-template-part">
        <?php block_header_area(); ?>
    </header>

    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

        <div class="recipe-container">
            <?php
                $author_id = $post->post_author;
                $featured_image = get_the_post_thumbnail_url($post->ID, 'large'); // Fetch featured image URL
            ?>
            <img src="<?php echo $featured_image ?>" srcset="<?php echo wp_get_attachment_image_srcset( get_post_thumbnail_id( $post->ID ), 'large' ); ?>" sizes="(max-width: 1200px) 100vw, 1200px" alt="<?php echo get_the_title(); ?>" class="recipe-featured-image">    
        </div>

        <div class="recipe-container">
            <div class="recipe-header">
                <?php $author_id = $post->post_author; 
                if (the_author_meta('avatar', $author_id) != '') { ?>
                    <img src="<?php the_author_meta('avatar', $author_id); ?>" alt="<?php echo the_author_meta('display_name', $author_id); ?>" class="recipe-author-avatar">
                <?php } else { ?>
                    <img src="https://secure.gravatar.com/avatar/7296eacf2efb09125e2a2e042de526c2?s=192&d=mm&r=g" alt="<?php echo the_author_meta('display_name', $author_id); ?>" class="recipe-author-avatar">
                <?php } ?>

                <div class="recipe-content">
                    <div class="recipe-title"><?php the_title(); ?></div>
                    <div>Recipe By <a href="" class="recipe-author"><?php echo ucwords(get_the_author_meta('first_name', $author_id) . " " . get_the_author_meta('last_name', $author_id)); ?></a></div>
                </div>
                <button class="print-button" onclick="window.print()">Print Recipe</button>
            </div>

            <div class="recipe-description">
                <?php echo get_the_excerpt();?>
            </div>

            <div class="recipe-meta">
                <div><strong>Cuisine:</strong>
                    <?php
                    $cuisines = get_the_terms($post->ID, 'cuisine');
                    if ($cuisines && !is_wp_error($cuisines)) {
                        $cuisine_list = array();
                        foreach ($cuisines as $cuisine) {
                            $cuisine_list[] = esc_html($cuisine->name);
                        }
                        echo implode(', ', $cuisine_list);
                    }
                    ?>
                </div>
                <div><strong>Course:</strong>
                    <?php
                    $courses = get_the_terms($post->ID, 'food_category');
                    if ($courses && !is_wp_error($courses)) {
                        $course_list = array();
                        foreach ($courses as $course) {
                            $course_list[] = esc_html($course->name);
                        }
                        echo implode(', ', $course_list);
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="recipe-container">
            <div class="details-container">
                <?php if(get_post_meta($post->ID, 'servings', true) != ''){?>
                <div class="details-item">
                    <strong>Servings</strong>
                    <div>
                        <?php
                        $servings = get_post_meta($post->ID, 'servings', true);
                        if (!empty($servings)) {
                            echo esc_html($servings);
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </div>
                </div>
                <?php } ?>
                
                <?php if(get_post_meta($post->ID, 'prep_time', true) != ''){?>
                <div class="details-item">
                    <strong>Prep Time</strong>
                    <div>
                        <?php
                        $prep_time = get_post_meta($post->ID, 'prep_time', true);
                        if (!empty($prep_time)) {
                            echo esc_html($prep_time) . " Minutes";
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </div>
                </div>
                <?php } ?>

                <?php if(get_post_meta($post->ID, 'cook_time', true) != ''){?>
                <div class="details-item">
                    <strong>Cook Time</strong>
                    <div>
                        <?php
                        $cook_time = get_post_meta($post->ID, 'cook_time', true);
                        if (!empty($cook_time)) {
                            echo esc_html($cook_time) . " Minutes";
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </div>
                </div>
                <?php } ?>

                <?php if(get_post_meta($post->ID, 'cook_time', true) != '' && get_post_meta($post->ID, 'prep_time', true) != ''){?>
                <div class="details-item">
                    <strong>Total Time</strong>
                    <div>
                        <?php
                        if (!empty($prep_time) && !empty($cook_time)) {
                            $total_time = intval($prep_time) + intval($cook_time);
                            $hours = floor($total_time / 60);
                            $minutes = $total_time % 60;

                            if ($hours > 0) {
                                echo esc_html($hours) . " Hours ";
                            }
                            echo esc_html($minutes) . " Minutes";
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>

        <?php if(get_post_meta($post->ID, 'ingredients', true) != ''){?>
        <div class="recipe-container recipe-section">
            <div class="section-title">Ingredients</div>
            <div class="section-content">
                <?php
                    $ingredients = get_post_meta($post->ID, 'ingredients', true);
                    if (!empty($ingredients)) {
                        echo wpautop($ingredients);
                    } else {
                        echo 'N/A';
                    }
                ?>
            </div>
        </div>
        <?php } ?>

        <?php if(get_post_meta($post->ID, 'equipment', true) != ''){?>
        <div class="recipe-container recipe-section">
            <div class="section-title">Equipment</div>
            <div class="section-content">
                <?php
                    $equipment = get_post_meta($post->ID, 'equipment', true);
                    if (!empty($equipment)) {
                        echo wpautop($equipment);
                    } else {
                        echo 'N/A';
                    }
                ?>
            </div>
        </div>
        <?php } ?>

        <?php if(get_post_meta($post->ID, 'nutritional_facts', true) != ''){?>
        <div class="recipe-container recipe-section">
            <div class="section-title">Nutritional Facts</div>
            <div class="section-content">
                <?php
                    $nutritional_facts = get_post_meta($post->ID, 'nutritional_facts', true);
                    if (!empty($nutritional_facts)) {
                        echo wpautop($nutritional_facts);
                    } else {
                        echo 'N/A';
                    }
                ?>
            </div>
        </div>
        <?php } ?>

        <?php if(get_post_meta($post->ID, 'instructions', true) != ''){?>
        <div class="recipe-container recipe-section">
            <div class="section-title">Instructions</div>
            <div class="section-content">
                <?php
                    $instructions = get_post_meta($post->ID, 'instructions', true);
                    if (!empty($instructions)) {
                        echo wpautop($instructions);
                    } else {
                        echo 'N/A';
                    }
                ?>
            </div>
        </div>
        <?php } ?>

        <?php if(get_post_meta($post->ID, 'notes', true) != ''){?>
        <div class="recipe-container recipe-section">
            <div class="section-title">Notes</div>
            <div class="section-content">
                <?php
                    $notes = get_post_meta($post->ID, 'notes', true);
                    if (!empty($notes)) {
                        echo wpautop($notes);
                    } else {
                        echo 'N/A';
                    }
                ?>
            </div>
        </div>
        <?php } ?>

        <?php if(get_post_meta($post->ID, 'video_url', true) != ''){?>
        <div class="recipe-container recipe-section">
            <div class="section-title">Recipe Video</div>
            <div class="section-content">
                <video width="100%" height="100%" controls>
                    <source src="<?php echo get_post_meta($post->ID, 'video_url', true);?>" type="video/mp4">
                    <source src="<?php echo get_post_meta($post->ID, 'video_url', true);?>" type="video/ogg">
                    Your browser does not support HTML video.
                </video>
            </div>
        </div>
        <?php } ?>

        <?php
            // If comments are open or we have at least one comment, load up the comment template
            if (comments_open() || get_comments_number()) {
                echo '<div id="comments" class="recipe-container comments-section">';
                comments_template();
                echo '</div>';
            }
        ?>
    </article>

    <footer class="wp-block-template-part site-footer">
        <?php block_footer_area(); ?>
    </footer>
    
    <?php wp_footer(); ?>
</body>
</html>
