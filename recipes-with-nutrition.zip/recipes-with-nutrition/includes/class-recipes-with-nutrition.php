<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://ghrix.com
 * @since      1.0.0
 *
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/includes
 * @author     Ghrix Technologies <hinald@ghrix.com>
 */
class Recipes_With_Nutrition {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Recipes_With_Nutrition_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'RECIPES_WITH_NUTRITION_VERSION' ) ) {
			$this->version = RECIPES_WITH_NUTRITION_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'recipes-with-nutrition';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();	
		$this->define_post_type_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Recipes_With_Nutrition_Loader. Orchestrates the hooks of the plugin.
	 * - Recipes_With_Nutrition_i18n. Defines internationalization functionality.
	 * - Recipes_With_Nutrition_Admin. Defines all hooks for the admin area.
	 * - Recipes_With_Nutrition_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-recipes-with-nutrition-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-recipes-with-nutrition-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-recipes-with-nutrition-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-recipes-with-nutrition-public.php';

		$this->loader = new Recipes_With_Nutrition_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Recipes_With_Nutrition_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Recipes_With_Nutrition_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Recipes_With_Nutrition_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'add_meta_boxes', $plugin_admin, 'add_recipe_meta_boxes' );
    	$this->loader->add_action( 'save_post', $plugin_admin, 'save_recipe_meta_boxes' );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Recipes_With_Nutrition_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

	}

	private function define_post_type_hooks() {
        $this->loader->add_action('init', $this, 'create_recipe_post_type');
		$this->loader->add_action('init', $this, 'register_taxonomies');
    }

	public function create_recipe_post_type() {
        $labels = array(
            'name' => __('Recipes', 'text_domain'),
            'singular_name' => __('Recipe', 'text_domain'),
            'menu_name' => __('Recipes', 'text_domain'),
            'name_admin_bar' => __('Recipe', 'text_domain'),
            'add_new' => __('Add New', 'text_domain'),
            'add_new_item' => __('Add New Recipe', 'text_domain'),
            'new_item' => __('New Recipe', 'text_domain'),
            'edit_item' => __('Edit Recipe', 'text_domain'),
            'view_item' => __('View Recipe', 'text_domain'),
            'all_items' => __('All Recipes', 'text_domain'),
            'search_items' => __('Search Recipes', 'text_domain'),
            'not_found' => __('No recipes found.', 'text_domain'),
            'not_found_in_trash' => __('No recipes found in Trash.', 'text_domain')
        );

        $args = array(
            'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'recipe' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_icon'          => 'dashicons-food',
			'supports'           => array( 'title', 'author', 'thumbnail', 'comments', 'excerpt' ),
			'template'           => array( array( 'recipe' ) ), // Add this line for custom template
        );

        register_post_type('recipe', $args);
    }

	public function register_taxonomies() {
		// Register 'Food Categories' taxonomy
		$labels = array(
			'name' => _x('Food Categories', 'taxonomy general name', 'text_domain'),
			'singular_name' => _x('Food Category', 'taxonomy singular name', 'text_domain'),
			'search_items' => __('Search Food Categories', 'text_domain'),
			'all_items' => __('All Food Categories', 'text_domain'),
			'parent_item' => __('Parent Food Category', 'text_domain'),
			'parent_item_colon' => __('Parent Food Category:', 'text_domain'),
			'edit_item' => __('Edit Food Category', 'text_domain'),
			'update_item' => __('Update Food Category', 'text_domain'),
			'add_new_item' => __('Add New Food Category', 'text_domain'),
			'new_item_name' => __('New Food Category Name', 'text_domain'),
			'menu_name' => __('Food Categories', 'text_domain'),
		);
	
		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'query_var' => true,
			'rewrite' => array('slug' => 'food-category'),
			'show_in_rest' => true, // Enable REST API support
		);
	
		register_taxonomy('food_category', array('recipe'), $args);
	
		// Register 'Cuisines' taxonomy
		$labels = array(
			'name' => _x('Cuisines', 'taxonomy general name', 'text_domain'),
			'singular_name' => _x('Cuisine', 'taxonomy singular name', 'text_domain'),
			'search_items' => __('Search Cuisines', 'text_domain'),
			'all_items' => __('All Cuisines', 'text_domain'),
			'parent_item' => __('Parent Cuisine', 'text_domain'),
			'parent_item_colon' => __('Parent Cuisine:', 'text_domain'),
			'edit_item' => __('Edit Cuisine', 'text_domain'),
			'update_item' => __('Update Cuisine', 'text_domain'),
			'add_new_item' => __('Add New Cuisine', 'text_domain'),
			'new_item_name' => __('New Cuisine Name', 'text_domain'),
			'menu_name' => __('Cuisines', 'text_domain'),
		);
	
		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'query_var' => true,
			'rewrite' => array('slug' => 'cuisine'),
			'show_in_rest' => true, // Enable REST API support
		);
	
		register_taxonomy('cuisine', array('recipe'), $args);
	}	

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Recipes_With_Nutrition_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	public static function activate() {
        // Trigger our function that registers the custom post type
		( new Recipes_With_Nutrition() )->create_recipe_post_type();
		// Clear the permalinks after the post type has been registered
		flush_rewrite_rules();
    }

    public static function deactivate() {
        // Unregister the post type, so the rules are no longer in memory
		unregister_post_type( 'recipe' );
		// Clear the permalinks to remove our post type's rules
    	flush_rewrite_rules();
    }

}
