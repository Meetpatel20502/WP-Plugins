<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://ghrix.com
 * @since      1.0.0
 *
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/includes
 * @author     Ghrix Technologies <hinald@ghrix.com>
 */
class Recipes_With_Nutrition_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
