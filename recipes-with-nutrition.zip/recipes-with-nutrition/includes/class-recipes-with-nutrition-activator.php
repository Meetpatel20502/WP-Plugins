<?php

/**
 * Fired during plugin activation
 *
 * @link       https://ghrix.com
 * @since      1.0.0
 *
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/includes
 * @author     Ghrix Technologies <hinald@ghrix.com>
 */
class Recipes_With_Nutrition_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
