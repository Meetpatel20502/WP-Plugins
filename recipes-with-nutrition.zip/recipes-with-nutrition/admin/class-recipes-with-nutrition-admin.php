<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://ghrix.com
 * @since      1.0.0
 *
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Recipes_With_Nutrition
 * @subpackage Recipes_With_Nutrition/admin
 * @author     Ghrix Technologies <hinald@ghrix.com>
 */
class Recipes_With_Nutrition_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Recipes_With_Nutrition_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Recipes_With_Nutrition_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/recipes-with-nutrition-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Recipes_With_Nutrition_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Recipes_With_Nutrition_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/recipes-with-nutrition-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function add_recipe_meta_boxes() {
        add_meta_box(
            'recipe_details_meta_box',
            __('Recipe Details', 'text_domain'),
            array($this, 'display_recipe_meta_box'),
            'recipe',
            'normal',
            'high'
        );
    }

    public function display_recipe_meta_box($post) {
        wp_nonce_field('recipe_meta_box_nonce_action', 'recipe_meta_box_nonce');
    
        // Retrieve the saved values
        $servings = get_post_meta($post->ID, 'servings', true);
        $prep_time = get_post_meta($post->ID, 'prep_time', true);
        $cook_time = get_post_meta($post->ID, 'cook_time', true);
        $equipment = get_post_meta($post->ID, 'equipment', true);
        $ingredients = get_post_meta($post->ID, 'ingredients', true);
        $instructions = get_post_meta($post->ID, 'instructions', true);
        $nutritional_facts = get_post_meta($post->ID, 'nutritional_facts', true);
        $notes = get_post_meta($post->ID, 'notes', true);
        $video_url = get_post_meta($post->ID, 'video_url', true);
    
        ?>
        <label for="servings"><?php _e('Servings:', 'recipes-with-nutrition'); ?></label>
        <input type="number" id="servings" name="servings" style="width: 100%;" value="<?php echo esc_attr($servings); ?>" min="1">
        <br><br>
    
        <label for="prep_time"><?php _e('Prep Time (in minutes):', 'recipes-with-nutrition'); ?></label>
        <input type="number" id="prep_time" name="prep_time" style="width: 100%;" value="<?php echo esc_attr($prep_time); ?>" min="0">
        <br><br>
    
        <label for="cook_time"><?php _e('Cook Time (in minutes):', 'recipes-with-nutrition'); ?></label>
        <input type="number" id="cook_time" name="cook_time" style="width: 100%;" value="<?php echo esc_attr($cook_time); ?>" min="0">
        <br><br>
    
        <label for="equipment"><?php _e('Equipment:', 'recipes-with-nutrition'); ?></label>
        <textarea id="equipment" name="equipment" rows="4" cols="50" style="width: 100%;"><?php echo esc_textarea($equipment); ?></textarea>
        <br><br>
    
        <label for="ingredients"><?php _e('Ingredients:', 'recipes-with-nutrition'); ?></label>
        <textarea id="ingredients" name="ingredients" rows="4" cols="50" style="width: 100%;"><?php echo esc_textarea($ingredients); ?></textarea>
        <br><br>
    
        <label for="instructions"><?php _e('Instructions:', 'recipes-with-nutrition'); ?></label>
        <?php
        $content = wp_kses_post($instructions); // Ensure proper formatting
        $editor_id = 'instructions';
        wp_editor($content, $editor_id, array('textarea_name' => 'instructions'));
        ?>
        <br><br>
    
        <label for="nutritional_facts"><?php _e('Nutritional Facts:', 'recipes-with-nutrition'); ?></label>
        <?php
        $content = wp_kses_post($nutritional_facts); // Allow HTML tags
        $editor_id = 'nutritional_facts';
        wp_editor($content, $editor_id, array('textarea_name' => 'nutritional_facts'));
        ?>
        <br><br>
    
        <label for="notes"><?php _e('Notes:', 'recipes-with-nutrition'); ?></label>
        <?php
        $content = wp_kses_post($notes); // Ensure proper formatting
        $editor_id = 'notes';
        wp_editor($content, $editor_id, array('textarea_name' => 'notes'));
        ?>
        <br><br>
    
        <label for="video_url"><?php _e('Video URL:', 'recipes-with-nutrition'); ?></label>
        <input type="url" id="video_url" name="video_url" value="<?php echo esc_url($video_url); ?>" style="width: 100%;">
        <br><br>
        <?php
    }    

    public function save_recipe_meta_boxes($post_id) {
        if (!isset($_POST['recipe_meta_box_nonce']) || !wp_verify_nonce($_POST['recipe_meta_box_nonce'], 'recipe_meta_box_nonce_action')) {
            return;
        }
    
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
    
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    
        // Save servings, prep time, cook time, equipment, ingredients, instructions, nutritional facts, notes, and video URL.
        $fields = array(
            'servings',
            'prep_time',
            'cook_time',
            'equipment',
            'ingredients',
            'instructions',
            'nutritional_facts',
            'notes',
            'video_url',
        );
    
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                // For textarea fields (except instructions, nutritional_facts, notes), sanitize text area.
                if (!in_array($field, array('instructions', 'nutritional_facts', 'notes'))) {
                    update_post_meta($post_id, $field, sanitize_textarea_field($_POST[$field]));
                } else {
                    update_post_meta($post_id, $field, $_POST[$field]); // Save as is without wpautop or other filtering
                }
            }
        }
    }
    

}
