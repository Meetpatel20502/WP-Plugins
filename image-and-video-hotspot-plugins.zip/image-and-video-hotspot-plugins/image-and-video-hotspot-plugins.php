<?php
/**
 * The plugin bootstrap file
 *
 * This file is red by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://ghrix.com
 * @since             1.0.0
 * @package           Image_And_Video_Hotspot
 *
 * @wordpress-plugin
 * Plugin Name:       Image and Video Hotspot
 * Plugin URI:        https://ghrix.com
 * Description:       Give your image and video the hotspot section for great view.
 * Version:           1.0.0
 * Author:            Ghrix
 * Author URI:        https://ghrix.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       image-and-video-hotspot-plugins
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
class ImageAndVideoHotspot {
    public function __construct() {
        add_action('init', array($this, 'register_custom_post_type'));
        add_action('admin_menu', array($this, 'add_plugin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('wp_ajax_save_hotspots', array($this, 'save_hotspots'));
        add_action('wp_ajax_delete_hotspot', array($this, 'delete_hotspot'));
        add_shortcode('image_hotspot', array($this, 'render_image_hotspot'));
        add_shortcode('video_hotspot', array($this, 'render_video_hotspot'));
        add_shortcode('hotspot_image', array($this, 'render_hotspot_image_shortcode'));
        add_action('admin_post_update_hotspot', array($this, 'update_hotspot'));
    }

    public function add_plugin_menu() {
        add_menu_page(
            'Hotspots',
            'Hotspots',
            'manage_options',
            'hotspots',
            array($this, 'render_hotspots_page'),
            'dashicons-location-alt',
            20
        );
    
        // Keep only one submenu page for 'All Hotspots'
        add_submenu_page(
            'hotspots',
            'All Hotspots',
            'All Hotspots',
            'manage_options',
            'hotspots',
            array($this, 'render_hotspots_page')
        );
    
        add_submenu_page(
            'hotspots',
            'Add New Hotspot',
            'Add New Hotspot',
            'manage_options',
            'add-new-hotspot',
            array($this, 'render_hotspot_editor')
        );
    }

    public function render_hotspots_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('All Hotspots', 'image-and-video-hotspot'); ?></h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Title', 'image-and-video-hotspot'); ?></th>
                        <th><?php esc_html_e('Shortcode', 'image-and-video-hotspot'); ?></th>
                        <th><?php esc_html_e('Actions', 'image-and-video-hotspot'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $args = array(
                        'post_type' => 'hotspot',
                        'posts_per_page' => -1
                    );
                    $hotspot_query = new WP_Query($args);
    
                    if ($hotspot_query->have_posts()) :
                        while ($hotspot_query->have_posts()) : $hotspot_query->the_post();
                            $post_id = get_the_ID();
                            $title = get_the_title();
                            $shortcode = '[hotspot id="' . esc_attr($post_id) . '"]';
                            ?>
                            <tr>
                                <td><?php echo esc_html($title); ?></td>
                                <td><?php echo esc_html($shortcode); ?></td>
                                <td>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=add-new-hotspot&post_id=' . $post_id)); ?>" class="button"><?php esc_html_e('Edit', 'image-and-video-hotspot'); ?></a>
                                    <a href="#" class="button delete-hotspot" data-post-id="<?php echo esc_attr($post_id); ?>"><?php esc_html_e('Delete', 'image-and-video-hotspot'); ?></a>
                                </td>
                            </tr>
                            <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                        ?>
                        <tr>
                            <td colspan="3"><?php esc_html_e('No hotspots found.', 'image-and-video-hotspot'); ?></td>
                        </tr>
                        <?php
                    endif;
                    ?>
                </tbody>
            </table>
        </div>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('.delete-hotspot').click(function(e) {
                e.preventDefault();
                if (confirm('<?php esc_html_e('Are you sure you want to delete this hotspot?', 'image-and-video-hotspot'); ?>')) {
                    var postId = $(this).data('post-id');
                    $.ajax({
                        type: 'POST',
                        url: ajaxurl,
                        data: {
                            action: 'delete_hotspot',
                            post_id: postId
                        },
                        success: function(response) {
                            if (response.success) {
                                location.reload();
                            } else {
                                alert('<?php esc_html_e('Error deleting hotspot.', 'image-and-video-hotspot'); ?>');
                            }
                        },
                        error: function(error) {
                            console.error(error);
                            alert('<?php esc_html_e('Error occurred while deleting hotspot.', 'image-and-video-hotspot'); ?>');
                        }
                    });
                }
            });
        });
        </script>
        <?php
    }

    public function render_hotspot_editor() {
        include_once(plugin_dir_path(__FILE__) . 'admin/hotspot-editor.php');
    }

    public function enqueue_admin_scripts($hook_suffix) {
        wp_enqueue_media();
        wp_enqueue_style('image-and-video-hotspot-admin', plugin_dir_url(__FILE__) . 'admin/css/image-and-video-hotspot-plugins-admin.css');
        wp_enqueue_script('image-and-video-hotspot-admin', plugin_dir_url(__FILE__) . 'admin/js/image-and-video-hotspot-plugins-admin.js', array('jquery'), null, true);
    }

    public function enqueue_frontend_scripts() {
        wp_enqueue_style('image-and-video-hotspot', plugin_dir_url(__FILE__) . 'public/css/image-and-video-hotspot-plugins-public.css');
        wp_enqueue_script('image-and-video-hotspot', plugin_dir_url(__FILE__) . 'public/js/image-and-video-hotspot-plugins-public.js', array('jquery'), null, true);
    }

    public function save_hotspots() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }

        $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
        $image_url = isset($_POST['image_url']) ? esc_url_raw($_POST['image_url']) : '';
        $video_url = isset($_POST['video_url']) ? esc_url_raw($_POST['video_url']) : '';
        $hotspots = isset($_POST['hotspots']) ? sanitize_text_field($_POST['hotspots']) : '';
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

        error_log('Received data:');
        error_log(print_r($_POST, true));

        if (($image_url && $video_url) || !$hotspots) {
            wp_send_json_error(array('message' => 'Please select either an image or a video.'));
        }

        $post_data = array(
            'post_title' => $title,
            'post_content' => '',
            'post_status' => 'publish',
            'post_type' => 'hotspot'
        );

        if ($post_id) {
            $post_data['ID'] = $post_id;
            $post_id = wp_update_post($post_data);
        } else {
            $post_id = wp_insert_post($post_data);
        }

        if ($post_id && !is_wp_error($post_id)) {
            update_post_meta($post_id, '_image_url', $image_url);
            update_post_meta($post_id, '_video_url', $video_url);
            update_post_meta($post_id, '_hotspots', $hotspots);

            wp_send_json_success(array('post_id' => $post_id));
        } else {
            wp_send_json_error(array('message' => 'Error saving hotspot.'));
        }
    }

    public function delete_hotspot() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }

        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

        if ($post_id && get_post($post_id)) {
            wp_delete_post($post_id, true);
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'Hotspot not found.'));
        }
    }

    public function render_image_hotspot($atts) {
        $atts = shortcode_atts(array(
            'id' => ''
        ), $atts, 'image_hotspot');

        $post_id = intval($atts['id']);
        $image_url = get_post_meta($post_id, '_image_url', true);
        $hotspots = get_post_meta($post_id, '_hotspots', true);

        ob_start();
        ?>
        <div class="hotspot-container">
            <img src="<?php echo esc_url($image_url); ?>" alt="Hotspot Image">
            <?php echo $hotspots; // Render the hotspots ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_video_hotspot($atts) {
        $atts = shortcode_atts(array(
            'id' => ''
        ), $atts, 'video_hotspot');

        $post_id = intval($atts['id']);
        $video_url = get_post_meta($post_id, '_video_url', true);
        $hotspots = get_post_meta($post_id, '_hotspots', true);

        ob_start();
        ?>
        <div class="hotspot-container">
            <video src="<?php echo esc_url($video_url); ?>" controls></video>
            <?php echo $hotspots; // Render the hotspots ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function render_hotspot_image_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => ''
        ), $atts, 'hotspot_image');

        $post_id = intval($atts['id']);
        $image_url = get_post_meta($post_id, '_image_url', true);
        $video_url = get_post_meta($post_id, '_video_url', true);
        $hotspots = get_post_meta($post_id, '_hotspots', true);

        ob_start();
        ?>
        <div class="hotspot-container">
            <?php if ($image_url) : ?>
                <img src="<?php echo esc_url($image_url); ?>" alt="Hotspot Image">
            <?php elseif ($video_url) : ?>
                <video src="<?php echo esc_url($video_url); ?>" controls></video>
            <?php endif; ?>
            <?php echo $hotspots; // Render the hotspots ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function update_hotspot() {
        // Your implementation for updating a hotspot goes here
    }
}

new ImageAndVideoHotspot();

function display_image_with_hotspots($atts) {
    static $instance_id = 0;
    $instance_id++;

    $atts = shortcode_atts(array(
        'id' => get_the_ID(),
    ), $atts, 'hotspot');

    $post_id = intval($atts['id']);
    $image_url = esc_url(get_post_meta($post_id, '_image_url', true));
    $video_url = esc_url(get_post_meta($post_id, '_video_url', true));
    $hotspots = get_post_meta($post_id, '_hotspots', true);
    $hotspots_data = $hotspots ? json_decode($hotspots, true) : [];

    ob_start();
    ?>
    <div id="frontend-hotspot-container-<?php echo $instance_id; ?>" style="position: relative;">
        <?php if ($image_url): ?>
            <img id="frontend-selected-image-<?php echo $instance_id; ?>" src="<?php echo $image_url; ?>" alt="Selected Image" style="max-width: 100%; height: auto;" />
        <?php endif; ?>
        <?php if ($video_url): ?>
            <video id="frontend-selected-video-<?php echo $instance_id; ?>" controls style="max-width: 100%; height: auto;">
                <source id="frontend-selected-video-source-<?php echo $instance_id; ?>" src="<?php echo $video_url; ?>" type="video/mp4">
            </video>
        <?php endif; ?>
    </div>

    <!-- Hotspot Modal -->
    <div id="frontend-hotspot-modal-<?php echo $instance_id; ?>" style="display:none; position: absolute; background: white; border: 1px solid black; padding: 10px; z-index: 1000;">
        <div id="frontend-hotspot-modal-content-<?php echo $instance_id; ?>">
            <p id="frontend-hotspot-tooltip-<?php echo $instance_id; ?>" style="cursor: pointer; text-decoration: underline; color: blue;"></p>
            <button type="button" id="frontend-close-hotspot-modal-<?php echo $instance_id; ?>"><?php esc_html_e('Close', 'image-and-video-hotspot'); ?></button>
        </div>
    </div>

    <style>
    .hotspot-dot {
        cursor: pointer;
    }
    #frontend-hotspot-modal-<?php echo $instance_id; ?> {
        position: absolute;
        background: white;
        border: 1px solid black;
        padding: 10px;
        z-index: 1000;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); /* Optional: Adds a shadow for depth */
        border-radius: 5px; /* Optional: Rounded corners */
        margin-top: 10px; /* Optional: Adjust margin for spacing */
        margin-left: 10px; /* Optional: Adjust margin for spacing */
    }
    #frontend-hotspot-tooltip-<?php echo $instance_id; ?> {
        cursor: pointer;
        text-decoration: underline;
        color: blue;
        padding: 5px; /* Adjust padding for the tooltip */
    }
</style>

    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            function displayHotspots(hotspots, instanceId) {
                const container = document.getElementById('frontend-hotspot-container-' + instanceId);
                const image = document.getElementById('frontend-selected-image-' + instanceId);
                const video = document.getElementById('frontend-selected-video-' + instanceId);

                if (!hotspots || hotspots.length === 0) {
                    return;
                }

                container.querySelectorAll('.hotspot-dot').forEach(dot => dot.remove());
                hotspots.forEach((hotspot, index) => {
                    if (isHotspotVisible(hotspot, instanceId)) {
                        const dot = document.createElement('div');
                        dot.className = 'hotspot-dot';
                        dot.style.position = 'absolute';
                        dot.style.top = hotspot.top + '%';
                        dot.style.left = hotspot.left + '%';
                        dot.style.width = '10px';
                        dot.style.height = '10px';
                        dot.style.background = 'red';
                        dot.style.borderRadius = '50%';
                        dot.dataset.index = index;
                        container.appendChild(dot);

                        dot.addEventListener('click', function(e) {
                            e.stopPropagation();
                            showHotspotModal(hotspot, e.pageX, e.pageY, instanceId);
                        });
                    }
                });
            }

            function isHotspotVisible(hotspot, instanceId) {
                const video = document.getElementById('frontend-selected-video-' + instanceId);
                const currentTime = video ? video.currentTime : 0;
                return (currentTime >= (hotspot.start || 0)) && (currentTime <= (hotspot.end || Infinity));
            }

            function showHotspotModal(hotspot, x, y, instanceId) {
                const modal = document.getElementById('frontend-hotspot-modal-' + instanceId);
                const tooltipElement = document.getElementById('frontend-hotspot-tooltip-' + instanceId);
                tooltipElement.innerText = hotspot.tooltip;
                tooltipElement.setAttribute('data-url', hotspot.url); // Store URL in a data attribute
                tooltipElement.style.cursor = 'pointer';
                tooltipElement.style.textDecoration = 'underline';
                tooltipElement.style.color = 'blue';
                tooltipElement.addEventListener('click', function() {
                    const url = this.getAttribute('data-url');
                    if (url) {
                        window.open(url, '_blank');
                    }
                });

                modal.style.left = x + 'px';
                modal.style.top = y + 'px';
                modal.style.display = 'block';
            }

            function hideHotspotModal(instanceId) {
                const modal = document.getElementById('frontend-hotspot-modal-' + instanceId);
                modal.style.display = 'none';
            }

            const hotspots = <?php echo json_encode($hotspots_data); ?>;
            displayHotspots(hotspots, <?php echo $instance_id; ?>);

            const videoElement = document.getElementById('frontend-selected-video-' + <?php echo $instance_id; ?>);
            if (videoElement) {
                videoElement.addEventListener('timeupdate', function() {
                    displayHotspots(hotspots, <?php echo $instance_id; ?>);
                });
            }

            document.getElementById('frontend-close-hotspot-modal-' + <?php echo $instance_id; ?>).addEventListener('click', function() {
                hideHotspotModal(<?php echo $instance_id; ?>);
            });

            document.addEventListener('click', function(e) {
                if (e.target.closest('.hotspot-dot') === null) {
                    hideHotspotModal(<?php echo $instance_id; ?>);
                }
            });
        });
    </script>
    <style>
        .hotspot-dot {
            cursor: pointer;
        }
        #frontend-hotspot-modal-<?php echo $instance_id; ?> {
            position: absolute;
            background: white;
            border: 1px solid black;
            padding: 10px;
            z-index: 1000;
        }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('hotspot', 'display_image_with_hotspots');



