<?php
class Image_And_Video_Hotspot_Plugins {

	public function run() {
		add_action( 'add_meta_boxes', array( $this, 'add_hotspot_metaboxes' ) );
		add_action( 'save_post', array( $this, 'save_hotspot_metabox' ) );
		add_shortcode( 'hotspot', array( $this, 'display_hotspot_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	public function add_hotspot_metaboxes() {
		add_meta_box(
			'hotspot_metabox',
			__( 'Hotspot Data', 'image-and-video-hotspot-plugins' ),
			array( $this, 'render_hotspot_metabox' ),
			null,
			'normal',
			'high'
		);
	}

	public function render_hotspot_metabox( $post ) {
		wp_nonce_field( 'save_hotspot_metabox', 'hotspot_metabox_nonce' );

		$hotspot_data = get_post_meta( $post->ID, '_hotspot_data', true );

		echo '<label for="hotspot_data">';
		_e( 'Hotspot Data (JSON format)', 'image-and-video-hotspot-plugins' );
		echo '</label>';
		echo '<textarea id="hotspot_data" name="hotspot_data" rows="5" style="width:100%;">' . esc_textarea( $hotspot_data ) . '</textarea>';
	}

	public function save_hotspot_metabox( $post_id ) {
		if ( ! isset( $_POST['hotspot_metabox_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $_POST['hotspot_metabox_nonce'], 'save_hotspot_metabox' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['hotspot_data'] ) ) {
			return;
		}

		$hotspot_data = sanitize_textarea_field( $_POST['hotspot_data'] );

		update_post_meta( $post_id, '_hotspot_data', $hotspot_data );
	}

	public function display_hotspot_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id' => '',
			),
			$atts,
			'hotspot'
		);

		if ( empty( $atts['id'] ) ) {
			return '';
		}

		$post = get_post( $atts['id'] );

		if ( ! $post ) {
			return '';
		}

		$hotspot_data = get_post_meta( $post->ID, '_hotspot_data', true );
		$content      = apply_filters( 'the_content', $post->post_content );

		ob_start();
		?>
		<div class="hotspot-container">
			<?php echo $content; ?>
			<script type="application/json" class="hotspot-data"><?php echo esc_html( $hotspot_data ); ?></script>
		</div>
		<?php
		return ob_get_clean();
	}

	public function enqueue_scripts() {
		wp_enqueue_script( 'hotspot-script', plugin_dir_url( __FILE__ ) . '../public/js/image-and-video-hotspot-plugins-public.js', array( 'jquery' ), IMAGE_AND_VIDEO_HOTSPOT_PLUGINS_VERSION, true );
		wp_enqueue_style( 'hotspot-style', plugin_dir_url( __FILE__ ) . '../public/css/image-and-video-hotspot-plugins-public.css', array(), IMAGE_AND_VIDEO_HOTSPOT_PLUGINS_VERSION );
	}
}
