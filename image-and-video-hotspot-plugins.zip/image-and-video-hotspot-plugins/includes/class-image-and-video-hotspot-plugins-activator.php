<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://ghrix.com
 * @since      1.0.0
 *
 * @package    Image_And_Video_Hotspot_Plugins
 * @subpackage Image_And_Video_Hotspot_Plugins/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Image_And_Video_Hotspot_Plugins
 * @subpackage Image_And_Video_Hotspot_Plugins/includes
 * @author     Ghrix <hinald@ghrix.com>
 */
class Image_And_Video_Hotspot_Plugins_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
