	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

		/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

		jQuery(document).ready(function($) {
			var mediaUploader;
			var hotspots = [];
		
			$('#select-image-button').click(function(e) {
				e.preventDefault();
				if (mediaUploader) {
					mediaUploader.open();
					return;
				}
		
				mediaUploader = wp.media({
					title: 'Choose Image',
					button: {
						text: 'Choose Image'
					},
					multiple: false
				});
		
				mediaUploader.on('select', function() {
					var attachment = mediaUploader.state().get('selection').first().toJSON();
					$('#selected-image-container').html('<img src="' + attachment.url + '" id="selected-image" style="max-width: 100%;"/>');
					$('#hotspots-data').val('');
					hotspots = [];
				});
		
				mediaUploader.open();
			});
		
			// Function to display the hotspots
			function displayHotspots() {
				$('#selected-image-container .hotspot').remove();
				hotspots.forEach(function(hotspot, index) {
					var hotspotElement = $('<div class="hotspot" style="position: absolute; top: ' + hotspot.top + '%; left: ' + hotspot.left + '%;"></div>');
					var tooltipElement = $('<span class="hotspot-tooltip">' + hotspot.tooltip + '<br><a href="' + hotspot.url + '" target="_blank">' + hotspot.url + '</a><button class="remove-hotspot" data-index="' + index + '">Remove</button></span>');
		
					hotspotElement.append(tooltipElement);
					hotspotElement.hover(
						function() { tooltipElement.show(); },
						function() { tooltipElement.hide(); }
					);
		
					$('#selected-image-container').append(hotspotElement);
				});
			}
		
			// Handle image click to add a hotspot
			$('#selected-image-container').on('click', '#selected-image', function(e) {
				var imageOffset = $(this).offset();
				var clickX = (e.pageX - imageOffset.left) / $(this).width() * 100;
				var clickY = (e.pageY - imageOffset.top) / $(this).height() * 100;
		
				$('#hotspot-modal').data('top', clickY).data('left', clickX).show();
			});
		
			// Handle adding hotspot
			$('#add-hotspot-button').click(function() {
				var tooltip = $('#hotspot-tooltip').val();
				var url = $('#hotspot-url').val();
				var top = $('#hotspot-modal').data('top');
				var left = $('#hotspot-modal').data('left');
		
				if (tooltip) {
					if (!url) {
						url = '#'; // Set a default URL if none provided
					}
					hotspots.push({ top: top, left: left, tooltip: tooltip, url: url });
					$('#hotspots-data').val(JSON.stringify(hotspots));
					displayHotspots();
					$('#hotspot-modal').hide();
					$('#hotspot-tooltip').val('');
					$('#hotspot-url').val('');
				} else {
					alert('Please enter a tooltip for the hotspot.');
				}
			});
		
			// Handle cancel button
			$('#cancel-hotspot-button').click(function() {
				$('#hotspot-modal').hide();
				$('#hotspot-tooltip').val('');
				$('#hotspot-url').val('');
			});
		
			// Handle removing hotspot
			$('#selected-image-container').on('click', '.remove-hotspot', function() {
				var index = $(this).data('index');
				hotspots.splice(index, 1);
				$('#hotspots-data').val(JSON.stringify(hotspots));
				displayHotspots();
		});
	
		// Hide the modal if clicked outside
		$(document).mouseup(function(e) {
			var container = $("#hotspot-modal");
			if (!container.is(e.target) && container.has(e.target).length === 0) {
				container.hide();
				$('#hotspot-tooltip').val('');
				$('#hotspot-url').val('');
			}
		});
	});	

