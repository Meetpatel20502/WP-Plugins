	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	jQuery(document).ready(function($) {
		var mediaUploader;
		var hotspots = [];

	
		// Function to display the hotspots
		function displayHotspots() {
			$('#selected-image-container .hotspot').remove();
			hotspots.forEach(function(hotspot, index) {
				var hotspotElement = $('<div class="hotspot" style="position: absolute; top: ' + hotspot.top + '%; left: ' + hotspot.left + '%;"></div>');
				var tooltipElement = $('<span class="hotspot-tooltip">' + hotspot.tooltip + '<br><a href="' + hotspot.url + '" target="_blank">' + hotspot.url + '</a><button class="remove-hotspot" data-index="' + index + '">Remove</button></span>');
	
				hotspotElement.append(tooltipElement);
				hotspotElement.hover(
					function() { tooltipElement.show(); },
					function() { tooltipElement.hide(); }
				);
	
				$('#selected-image-container').append(hotspotElement);
			});
		}
	
		// Handle image click to add a hotspot
		$('#selected-image-container').on('click', '#selected-image', function(e) {
			var imageOffset = $(this).offset();
			var clickX = (e.pageX - imageOffset.left) / $(this).width() * 100;
			var clickY = (e.pageY - imageOffset.top) / $(this).height() * 100;
	
			$('#hotspot-modal').data('top', clickY).data('left', clickX).show();
		});
	
		// Handle adding hotspot
		$('#add-hotspot-button').click(function() {
			var tooltip = $('#hotspot-tooltip').val();
			var url = $('#hotspot-url').val();
			var top = $('#hotspot-modal').data('top');
			var left = $('#hotspot-modal').data('left');
	
			if (tooltip) {
				if (!url) {
					url = '#'; // Set a default URL if none provided
				}
				hotspots.push({ top: top, left: left, tooltip: tooltip, url: url });
				$('#hotspots-data').val(JSON.stringify(hotspots));
				displayHotspots();
	
				// Update the hotspot tooltip element with tooltip and URL
				var hotspotElement = $('<div class="hotspot" style="position: absolute; top: ' + top + '%; left: ' + left + '%;"></div>');
				var tooltipElement = $('<span class="hotspot-tooltip">' + tooltip + '<br><a href="' + url + '" target="_blank">' + url + '</a><button class="remove-hotspot" data-index="' + (hotspots.length - 1) + '">Remove</button></span>');
	
				hotspotElement.append(tooltipElement);
				hotspotElement.hover(
					function() { tooltipElement.show(); },
					function() { tooltipElement.hide(); }
				);
	
				$('#selected-image-container').append(hotspotElement);
	
				$('#hotspot-modal').hide();
				$('#hotspot-tooltip').val('');
				$('#hotspot-url').val('');
			} else {
				alert('Please enter a tooltip for the hotspot.');
			}
		});
	
		// Handle cancel button
		$('#cancel-hotspot-button').click(function() {
			$('#hotspot-modal').hide();
			$('#hotspot-tooltip').val('');
			$('#hotspot-url').val('');
		});
	
		// Handle removing hotspot
		$('#selected-image-container').on('click', '.remove-hotspot', function() {
			var index = $(this).data('index');
			hotspots.splice(index, 1);
			$('#hotspots-data').val(JSON.stringify(hotspots));
			displayHotspots();
		});
	
		// Handle form submission
		$('#submit-hotspot').click(function(e) {
			e.preventDefault();
			var title = $('#hotspot-title').val();
			var image_url = $('#image-url').val();
			var video_url = $('#video-url').val();
			var hotspots_data = $('#hotspots-data').val();
			var post_id = $('#post-id').val();

			console.log('Submitting hotspot:', {
				title: title,
				image_url: image_url,
				video_url: video_url,
				hotspots_data: hotspots_data,
				post_id: post_id
			});

			if (!title) {
				alert('Please enter a title for the hotspot.');
				return;
			}
	
			// AJAX call to save the hotspots
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'save_hotspots',
					title: title,
					image_url: image_url,
					video_url: video_url,
					hotspots: hotspots_data,
					post_id: post_id,  // Pass the post ID if it exists
				},
				success: function(response) {
					alert('Hotspot data saved successfully!');
				},
				error: function(xhr, status, error) {
					console.error('Error saving hotspot data:');
					alert('Failed to save hotspot data.');
				}
			});
		});
	
		// Hide the modal if clicked outside
		$(document).mouseup(function(e) {
			var container = $("#hotspot-modal");
			if (!container.is(e.target) && container.has(e.target).length === 0) {
				container.hide();
				$('#hotspot-tooltip').val('');
				$('#hotspot-url').val('');
			}
		});
	});