<div id="hotspot-editor">
    <h2><?php esc_html_e('Hotspot 1Editor', 'image-and-video-hotspot'); ?></h2>
    <p><?php esc_html_e('Use the controls below to add and configure hotspots.', 'image-and-video-hotspot'); ?></p>
    <input type="button" id="select-image-button" class="button" value="<?php esc_attr_e('Select Image', 'image-and-video-hotspot'); ?>" />
    <div id="selected-image-container" style="position: relative;"></div>
    <input type="hidden" id="hotspots-data" name="hotspots" value="" />
    <input type="button" id="select-image-button" class="button" value="<?php esc_attr_e('Select Image', 'image-and-video-hotspot'); ?>" />
</div>

<!-- Hotspot Modal -->
<div id="hotspot-modal" style="display:none;">
    <label for="hotspot-tooltip"><?php esc_html_e('Enter Your Text:', 'image-and-video-hotspot'); ?></label>
    <input type="text" id="hotspot-tooltip" name="hotspot-tooltip" />
    <br>
    <label for="hotspot-url"><?php esc_html_e('Enter Your URL:', 'image-and-video-hotspot'); ?></label>
    <input type="text" id="hotspot-url" name="hotspot-url" />
    <button type="button" id="add-hotspot-button"><?php esc_html_e('Add Hotspot', 'image-and-video-hotspot'); ?></button>
    <button type="button" id="cancel-hotspot-button"><?php esc_html_e('Cancel', 'image-and-video-hotspot'); ?></button>
</div>
