    <?php
    // edit-hotspot.php

    if (!defined('ABSPATH')) {
        exit; // Exit if accessed directly
    }

    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized access');
    }

    $post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;

    if (!$post_id || get_post_type($post_id) !== 'hotspot') {
        wp_die('Invalid hotspot');
    }

    $title = get_the_title($post_id);
    $image_url = get_post_meta($post_id, '_image_url', true);
    $hotspots = get_post_meta($post_id, '_hotspots', true);
    $hotspots = !empty($hotspots) ? json_decode($hotspots, true) : [];

    ?>

    <div class="wrap">
        <h1><?php esc_html_e('Edit Hotspot', 'image-and-video-hotspot'); ?></h1>

        <form id="edit-hotspot-form" method="post" action="">
            <input type="hidden" name="post_id" value="<?php echo esc_attr($post_id); ?>">
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="hotspot-title"><?php esc_html_e('Hotspot Title', 'image-and-video-hotspot'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="hotspot_title" id="hotspot-title" value="<?php echo esc_attr($title); ?>" class="regular-text" required>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="hotspot-image-url"><?php esc_html_e('Image URL', 'image-and-video-hotspot'); ?></label>
                    </th>
                    <td>
                        <input type="hidden" name="hotspot_image_url" id="hotspot_image_url" value="<?php echo esc_url($image_url); ?>">
                        <button type="button" class="button upload-image"><?php esc_html_e('Select Image', 'image-and-video-hotspot'); ?></button>
                        <div id="selected-image-container" style="position: relative;">
                        <img id="selected-image" src="<?php echo esc_url($image_url); ?>" alt="<?php esc_html_e('Selected Image', 'image-and-video-hotspot'); ?>" style="max-width: 100%; height: auto; display: <?php echo !empty($image_url) ? 'block' : 'none'; ?>;">
                        <video id="selected-video" controls style="max-width: 100%; height: auto; display: <?php echo !empty($video_url) ? 'block' : 'none'; ?>;">
                            <source src="<?php echo esc_url($video_url); ?>" type="video/mp4">
                        </video>
                        <?php if (!empty($hotspots)): ?>
                            <?php foreach ($hotspots as $index => $hotspot): ?>
                                <div class="hotspot-dot" data-index="<?php echo esc_attr($index); ?>" style="position: absolute; top: <?php echo esc_attr($hotspot['top']); ?>%; left: <?php echo esc_attr($hotspot['left']); ?>%; width: 10px; height: 10px; background: red; border-radius: 50%;"></div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Hotspot', 'image-and-video-hotspot'); ?>">
            </p>
        </form>
    </div>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.upload-image').click(function(e) {
            e.preventDefault();
            var image = wp.media({
                title: '<?php esc_html_e('Select Image', 'image-and-video-hotspot'); ?>',
                multiple: false
            }).open().on('select', function() {
                var uploadedImage = image.state().get('selection').first();
                var imageUrl = uploadedImage.toJSON().url;
                $('#hotspot_image_url').val(imageUrl);
                $('#selected-image').attr('src', imageUrl);
            });
        });

        function displayHotspots(hotspots) {
            $('#selected-image-container').find('.hotspot-dot').remove();
            hotspots.forEach((hotspot, index) => {
                $('#selected-image-container').append(`
                    <div class="hotspot-dot" data-index="${index}" style="position: absolute; top: ${hotspot.top}%; left: ${hotspot.left}%; width: 10px; height: 10px; background: red; border-radius: 50%;"></div>
                `);
            });
        }

        function loadHotspots() {
            const hotspotsData = $('#hotspots-data').val();
            return hotspotsData ? JSON.parse(hotspotsData) : [];
        }

        function saveHotspots(hotspots) {
            $('#hotspots-data').val(JSON.stringify(hotspots));
        }

        const hotspots = loadHotspots();
        displayHotspots(hotspots);

        $('#selected-image').click(function(e) {
            const offset = $(this).offset();
            const left = ((e.pageX - offset.left) / $(this).width()) * 100;
            const top = ((e.pageY - offset.top) / $(this).height()) * 100;

            $('#hotspot-modal').css({ top: e.pageY, left: e.pageX }).show();

            $('#add-hotspot-button').off('click').on('click', function() {
                const tooltip = $('#hotspot-tooltip').val();
                const url = $('#hotspot-url').val();
                hotspots.push({ tooltip, url, top, left });
                saveHotspots(hotspots);
                displayHotspots(hotspots);
                $('#hotspot-modal').hide();
            });
        });

        $('#cancel-hotspot-button').click(function() {
            $('#hotspot-modal').hide();
        });

        $('#submit-hotspot').click(function(e) {
            e.preventDefault();

            var postData = {
                action: 'save_hotspot',
                post_id: $('#post-id').val(),
                title: $('#hotspot-title').val(),
                hotspots: $('#hotspots-data').val(),
                image_url: $('#image-url').val()
            };

            $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: postData,
                success: function(response) {
                    if (response.success) {
                        alert('<?php esc_html_e('Hotspot saved successfully.', 'image-and-video-hotspot'); ?>');
                        window.location.href = '<?php echo esc_url(admin_url('admin.php?page=all-hotspots')); ?>';
                    } else {
                        alert('<?php esc_html_e('Error saving hotspot.', 'image-and-video-hotspot'); ?>');
                    }
                },
                error: function(error) {
                    console.error(error);
                    alert('<?php esc_html_e('Error occurred while saving hotspot.', 'image-and-video-hotspot'); ?>');
                }
            });
        });
    });
    </script>
