<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class ImageAndVideoHotspot_Admin {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );

        // Enqueue scripts and styles
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
    }

    public function add_admin_menu() {
        add_menu_page(
            'Image and Video Hotspot',


            'Image & Video Hotspot',
            'manage_options',
            'image-and-video-hotspot',
            array( $this, 'create_admin_page' ),
            'dashicons-location',
            100
        );
    }

    public function create_admin_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Image and Video Hotspot', 'image-and-video-hotspot' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'image_and_video_hotspot_group' );
                do_settings_sections( 'image-and-video-hotspot' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function register_settings() {
        register_setting( 'image_and_video_hotspot_group', 'image_and_video_hotspot_options' );

        add_settings_section(
            'image_and_video_hotspot_section',
            __( 'Settings', 'image-and-video-hotspot' ),
            null,
            'image-and-video-hotspot'
        );

        add_settings_field(
            'image_and_video_hotspot_field',
            __( 'Hotspot Editor', 'image-and-video-hotspot' ),
            array( $this, 'hotspot_editor_callback' ),
            'image-and-video-hotspot',
            'image_and_video_hotspot_section'
        );
    }

    public function hotspot_editor_callback() {
    if (isset($_POST['hotspots_data'])) {
        // Save the hotspots data
        $hotspots_data = sanitize_textarea_field($_POST['hotspots_data']);
        update_option('image_and_video_hotspot_hotspots_data', $hotspots_data);
        echo '<div class="updated"><p>' . esc_html__('Hotspots data saved.', 'image-and-video-hotspot') . '</p></div>';
    }

    $hotspots_data = get_option('image_and_video_hotspot_hotspots_data', '');

    // Display the hotspot editor form
    require_once plugin_dir_path(__FILE__) . '/hotspot-editor.php';
}

}

new ImageAndVideoHotspot_Admin();