<div class="frame-container">
<div id="hotspot-editor">
    <h2 style="text-align:center; font-size:25px;"><?php esc_html_e('Hotspot Editor', 'image-and-video-hotspot'); ?></h2>
    <p style="text-align:center; margin-top:-10px;"><?php esc_html_e('Click on the image to add a hotspot or edit an existing hotspot.', 'image-and-video-hotspot'); ?></p>
    
    <label for="hotspot-title" style="font-weight: bold; font-size:15px; vertical-align: unset;"><?php esc_html_e('Title:', 'image-and-video-hotspot'); ?></label>
    <input type="text" id="hotspot-title" name="hotspot-title" value="<?php echo esc_attr(get_the_title($_GET['post_id'])); ?>" />
    <input type="button" id="select-image-button" class="button" value="<?php esc_attr_e('Select Image', 'image-and-video-hotspot'); ?>" />
    <input type="button" id="select-video-button" class="button" value="<?php esc_attr_e('Select Video', 'image-and-video-hotspot'); ?>" />

    <div id="selected-media-container" style="position: relative;">
        <img id="selected-image" src="<?php echo esc_url(get_post_meta($_GET['post_id'], '_image_url', true)); ?>" alt="Selected Image" style="max-width: 100%; height: auto; display: <?php echo esc_url(get_post_meta($_GET['post_id'], '_image_url', true)) ? 'block' : 'none'; ?>;" />
        <video id="selected-video" controls style="max-width: 100%; height: auto; display: <?php echo esc_url(get_post_meta($_GET['post_id'], '_video_url', true)) ? 'block' : 'none'; ?>;">
            <source id="selected-video-source" src="<?php echo esc_url(get_post_meta($_GET['post_id'], '_video_url', true)); ?>" type="video/mp4">
        </video>
    </div>
    
    <input type="hidden" id="hotspots-data" name="hotspots" value="<?php echo esc_attr(get_post_meta($_GET['post_id'], '_hotspots', true)); ?>" />
    <input type="hidden" id="image-url" name="image_url" value="<?php echo esc_url(get_post_meta($_GET['post_id'], '_image_url', true)); ?>" />
    <input type="hidden" id="video-url" name="video_url" value="<?php echo esc_url(get_post_meta($_GET['post_id'], '_video_url', true)); ?>" />
    <input type="hidden" id="post-id" name="post_id" value="<?php echo intval($_GET['post_id']); ?>" />
    
    <input type="submit" id="submit-hotspot" class="button button-primary" value="<?php esc_attr_e('Submit Hotspot', 'image-and-video-hotspot'); ?>" />
</div>

<!-- Hotspot Modal -->
<div id="hotspot-modal" style="display:none; position: absolute;">
    <div class="hotspot-modal-content">
        <label for="hotspot-tooltip"><?php esc_html_e('Enter Your Text:', 'image-and-video-hotspot'); ?></label><br>
        <input type="text" id="hotspot-tooltip" name="hotspot-tooltip" /><br>
        
        <label for="hotspot-url"><?php esc_html_e('Enter Your URL:', 'image-and-video-hotspot'); ?></label><br>
        <input type="text" id="hotspot-url" name="hotspot-url" /><br>
        
        <!-- Start and End Time fields for video -->
        <div id="video-time-fields" style="display: none;">
            <label for="hotspot-start-time"><?php esc_html_e('Start Time (seconds):', 'image-and-video-hotspot'); ?></label><br>
            <input type="number" id="hotspot-start-time" name="hotspot-start-time" min="0" step="1" value="0" /><br>
            
            <label for="hotspot-end-time"><?php esc_html_e('End Time (seconds):', 'image-and-video-hotspot'); ?></label><br>
            <input type="number" id="hotspot-end-time" name="hotspot-end-time" min="0" step="1" /><br>
        </div>
        
        <div class="hotspot-modal-buttons">
            <button type="button" id="save-hotspot-button"><?php esc_html_e('Save Hotspot', 'image-and-video-hotspot'); ?></button>
            <button type="button" id="remove-hotspot-button"><?php esc_html_e('Remove Hotspot', 'image-and-video-hotspot'); ?></button>
            <button type="button" id="cancel-hotspot-button"><?php esc_html_e('Cancel', 'image-and-video-hotspot'); ?></button>
        </div>
    </div>
</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    function displayHotspots(hotspots) {
        $('#selected-media-container').find('.hotspot-dot').remove();
        hotspots.forEach((hotspot, index) => {
            const isVisible = isHotspotVisible(hotspot);
            if (isVisible) {
                $('#selected-media-container').append(`
                    <div class="hotspot-dot" data-index="${index}" style="position: absolute; top: ${hotspot.top}%; left: ${hotspot.left}%; width: 10px; height: 10px; background: red; border-radius: 50%;"></div>
                `);
            }
        });
    }

    function isHotspotVisible(hotspot) {
        const currentTime = $('#selected-video').length ? $('#selected-video').get(0).currentTime : 0;
        return (currentTime >= (hotspot.start || 0)) && (currentTime <= (hotspot.end || Infinity));
    }

    function loadHotspots() {
        const hotspotsData = $('#hotspots-data').val();
        return hotspotsData ? JSON.parse(hotspotsData) : [];
    }

    function saveHotspots(hotspots) {
        $('#hotspots-data').val(JSON.stringify(hotspots));
    }

    let currentHotspotIndex = -1;
    const hotspots = loadHotspots();
    displayHotspots(hotspots);

    function checkMediaType() {
        if ($('#selected-image').is(':visible')) {
            $('#video-time-fields').hide();
        } else if ($('#selected-video').is(':visible')) {
            $('#video-time-fields').show();
        }
    }

    // Check media type on page load
    checkMediaType();

    $('#select-image-button').click(function(e) {
        e.preventDefault();
        var image = wp.media({
            title: '<?php esc_html_e('Select Image', 'image-and-video-hotspot'); ?>',
            library: { type: 'image' }, // Only show images in media uploader
            multiple: false
        }).open().on('select', function() {
            var uploadedImage = image.state().get('selection').first();
            var imageUrl = uploadedImage.toJSON().url;
            $('#image-url').val(imageUrl);
            $('#selected-image').attr('src', imageUrl).show();
            $('#selected-video').hide();
            $('#video-url').val('');
            image.close();

            // Hide video time fields when selecting an image
            $('#video-time-fields').hide();
            
            // Save hotspots for the selected image
            saveHotspots(hotspots);
            displayHotspots(hotspots);
        });
    });

    $('#select-video-button').click(function(e) {
        e.preventDefault();
        var video = wp.media({
            title: '<?php esc_html_e('Select Video', 'image-and-video-hotspot'); ?>',
            library: { type: 'video' },
            multiple: false
        }).open().on('select', function() {
            var uploadedVideo = video.state().get('selection').first();
            var videoUrl = uploadedVideo.toJSON().url;
            $('#video-url').val(videoUrl);
            $('#selected-video-source').attr('src', videoUrl);
            
            // Reset the video player to load the new source
            var selectedVideo = $('#selected-video').get(0);
            selectedVideo.load();
            
            // Display the video and hide the image
            $('#selected-video').css('display', 'block');
            $('#selected-image').css('display', 'none');
            
            // Show video time fields
            $('#video-time-fields').show();
            
            // Set default end time to video duration (if available)
            selectedVideo.onloadedmetadata = function() {
                const videoDuration = Math.floor(selectedVideo.duration);
                $('#hotspot-end-time').val(videoDuration);
                $('#hotspot-end-time').attr('max', videoDuration); // Set max attribute for end time
            };
            
            // Save hotspots for the selected video
            saveHotspots(hotspots);
            displayHotspots(hotspots);
        });
    });

    $('#selected-video').on('timeupdate', function() {
        displayHotspots(hotspots);
    });

    $('#selected-image, #selected-video').click(function(e) {
        const offset = $(this).offset();
        const left = ((e.pageX - offset.left) / $(this).width()) * 100;
        const top = ((e.pageY - offset.top) / $(this).height()) * 100;
        const currentTime = $(this).is('video') ? $(this).get(0).currentTime : 0;

        currentHotspotIndex = -1;
        $('#hotspot-tooltip').val('');
        $('#hotspot-url').val('');
        $('#hotspot-start-time').val('0'); // Set start time to 0 by default
        $('#hotspot-end-time').val(''); // Clear end time input
        
        if ($(this).is('video')) {
            // Set end time to video duration (if available)
            const selectedVideo = $(this).get(0);
            const videoDuration = Math.floor(selectedVideo.duration);
            $('#hotspot-end-time').val(videoDuration);
        }
        
        $('#hotspot-modal').css({ top: e.pageY, left: e.pageX }).show();
        $('#hotspot-modal').data('position', { left, top });
    });

    $(document).on('click', '.hotspot-dot', function(e) {
        e.stopPropagation();
        const index = $(this).data('index');
        currentHotspotIndex = index;
        const hotspot = hotspots[index];
        
        $('#hotspot-tooltip').val(hotspot.tooltip);
        $('#hotspot-url').val(hotspot.url);
        $('#hotspot-start-time').val(hotspot.start || 0);
        $('#hotspot-end-time').val(hotspot.end || '');
        $('#hotspot-modal').css({ top: e.pageY, left: e.pageX }).show();
    });

    $('#save-hotspot-button').click(function() {
        const position = $('#hotspot-modal').data('position');
        const tooltip = $('#hotspot-tooltip').val();
        const url = $('#hotspot-url').val();
        const start = parseInt($('#hotspot-start-time').val(), 10) || 0;
        const end = parseInt($('#hotspot-end-time').val(), 10) || Infinity;

        if (currentHotspotIndex >= 0) {
            hotspots[currentHotspotIndex] = { ...hotspots[currentHotspotIndex], tooltip, url, start, end };
        } else {
            hotspots.push({ ...position, tooltip, url, start, end });
        }

        saveHotspots(hotspots);
        displayHotspots(hotspots);
        $('#hotspot-modal').hide();
    });

    $('#remove-hotspot-button').click(function() {
        if (currentHotspotIndex >= 0) {
            hotspots.splice(currentHotspotIndex, 1);
            saveHotspots(hotspots);
            displayHotspots(hotspots);
            $('#hotspot-modal').hide();
        }
    });

    $('#cancel-hotspot-button').click(function() {
        $('#hotspot-modal').hide();
    });
});
</script>
