<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://ghrix.com/
 * @since      1.0.0
 *
 * @package    Scrum_Meeting
 * @subpackage Scrum_Meeting/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Scrum_Meeting
 * @subpackage Scrum_Meeting/includes
 * @author     Ghrix Technologies <info@ghrix.com>
 */
class Scrum_Meeting_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
