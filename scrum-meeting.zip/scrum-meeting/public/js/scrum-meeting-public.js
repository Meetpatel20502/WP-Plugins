(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	window.updateMeetingStatus = function(meetingId, status) {
        // Define the confirmation message based on the status
        var confirmationMessage = (status === 2) 
            ? 'Are you sure you have attended the meeting with webcam?' 
            : 'Are you sure you have attended the meeting without webcam?';

        // Show the confirmation dialog
        if (confirm(confirmationMessage)) {
            var currentTime = new Date().toISOString().slice(0, 19).replace('T', ' ');
            $.ajax({
                url: scrumMeeting.ajax_url,
                type: 'POST',
                data: {
                    action: 'update_meeting_status',
                    meeting_id: meetingId,
                    status: status,
                    log_time: currentTime, // Pass current time directly
                    security: scrumMeeting.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Hide the widget and show the confirmation message
                        var meetingCard = $('.cardbody[data-meeting-id="' + meetingId + '"]');
                        meetingCard.find('.card').hide();
                        meetingCard.append('<div class="card"><div class="confirmation">Today\'s Morning Meeting attended ' 
                            + (status === 2 ? 'with Webcam' : 'without Webcam') 
                            + ' - Logged on ' + currentTime.split(' ')[1] + '</div></div>');

                        // Show snackbar notification
                        showSnackbar();
                    } else {
                        alert('Failed to update meeting status');
                    }
                },
                error: function() {
                    alert('Error in AJAX request');
                }
            });
        }
    };

    // Function to show snackbar
    function showSnackbar() {
        var snackbar = document.getElementById("snackbar");
        snackbar.className = "show";
        setTimeout(function() {
            snackbar.className = snackbar.className.replace("show", "");
        }, 3000);
    }
        
    document.addEventListener('DOMContentLoaded', function() {
        attachEventListeners();
    
        function attachEventListeners() {
            var cells = document.querySelectorAll('.attendance-cell');
    
            cells.forEach(function(cell) {
                cell.addEventListener('mouseenter', function() {
                    var modal = this.querySelector('.modal');
                    if (modal) {
                        var rect = cell.getBoundingClientRect();
                        modal.style.top = rect.bottom + 'px';
                        modal.style.left = rect.left + 'px';
                        modal.style.display = "block";
                    }
                });
    
                cell.addEventListener('mouseleave', function() {
                    var modal = this.querySelector('.modal');
                    if (modal) {
                        modal.style.display = "none";
                    }
                });
            });
    
            var closeButtons = document.querySelectorAll('.close');
            closeButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    var modalId = this.getAttribute('data-modal-id');
                    var modal = document.getElementById(modalId);
                    if (modal) {
                        modal.style.display = "none";
                    }
                });
            });
        }

        var applyFilterButton = document.getElementById('apply_filter');
        if (applyFilterButton) {
            applyFilterButton.addEventListener('click', function() {
                var monthYear = document.getElementById('filter_month_year').value;
    
                jQuery.ajax({
                    type: 'POST',
                    url: scrumMeeting.ajax_url,
                    data: {
                        action: 'filter_scrum_meetings',
                        monthYear: monthYear
                    },
                    success: function(response) {
                        // Update the table container with the new table HTML
                        document.querySelector('.scrum-meeting-table-container').innerHTML = response;
                        // Re-attach event listeners to the new elements
                        attachEventListeners();
                    }
                });
            });
        }
    });

})( jQuery );
