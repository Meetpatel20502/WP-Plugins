<?php

/**
 * The plugin bootstrap file
 *
 * @link              https://ghrix.com/
 * @since             1.0.0
 * @package           Scrum_Meeting
 *
 * @wordpress-plugin
 * Plugin Name:       Scrum Meeting
 * Plugin URI:        https://ghrix.com/
 * Description:       This widget will only show after the scrum meeting start time and after 10 minutes is over of the scrum meeting. Admin can create Morning and Evening Scrum meeting for every user. Scrum meeting setting will have 2 fields (start and end time). As soon as the developer submits the form, the scrum attendance will be locked. This widget will be a short code that can be placed anywhere.
 * Version:           1.0.0
 * Author:            Ghrix Technologies
 * Author URI:        https://ghrix.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       scrum-meeting
 * Domain Path:       /languages
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Add admin menu and submenu
add_action('admin_menu', 'scrum_meeting_admin_menu');

function scrum_meeting_admin_menu() {
    add_menu_page(
        'Scrum Meetings',
        'Scrum Meetings',
        'manage_options',
        'scrum-meetings',
        'scrum_meeting_settings_page',
        'dashicons-calendar-alt',
        90
    );

    add_submenu_page(
        'scrum-meetings',
        'Set Meetings',
        'Set Meetings',
        'manage_options',
        'set-meetings',
        'scrum_meeting_set_meetings_page'
    );
}

// Enqueue custom CSS for the plugin
add_action('admin_enqueue_scripts', 'scrum_meeting_enqueue_admin_styles');
function scrum_meeting_enqueue_admin_styles() {
    wp_enqueue_style('scrum-meeting-admin-styles', plugin_dir_url(__FILE__) . 'public/css/scrum-meeting-public.css');
    
    wp_enqueue_script('scrum-meeting-script', plugin_dir_url(__FILE__) . 'public/js/scrum-meeting-public.js', array('jquery'), '1.0', true);

    wp_localize_script('scrum-meeting-script', 'scrumMeeting', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('update_meeting_status_nonce')
    ));
}

// Enqueue custom CSS and JS for the frontend
add_action('wp_enqueue_scripts', 'scrum_meeting_enqueue_public_styles');
function scrum_meeting_enqueue_public_styles() {
    wp_enqueue_style('scrum-meeting-public-styles', plugin_dir_url(__FILE__) . 'public/css/scrum-meeting-public.css');

    wp_enqueue_script('scrum-meeting-script', plugin_dir_url(__FILE__) . 'public/js/scrum-meeting-public.js', array('jquery'), '1.0', true);

    wp_localize_script('scrum-meeting-script', 'scrumMeeting', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('update_meeting_status_nonce')
    ));
}

// Register activation hook
register_activation_hook(__FILE__, 'scrum_meeting_create_table');

function scrum_meeting_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        submission_date DATE NOT NULL,
        meeting_type VARCHAR(10) NOT NULL,
        meeting_from TIME NOT NULL,
        meeting_to TIME NOT NULL,
        userid bigint(20) NOT NULL,
        status TINYINT(1) DEFAULT NULL,
        log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Register deactivation hook
register_deactivation_hook(__FILE__, 'scrum_meeting_drop_table');

function scrum_meeting_drop_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}

// Handle form submission
add_action('admin_post_save_scrum_meeting_settings', 'save_scrum_meeting_settings');
function save_scrum_meeting_settings() {
    global $wpdb;

    // Check if the user has the required capability
    if (!current_user_can('manage_options')) {
        return;
    }

    // Check if the nonce is set and valid
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'save_scrum_meeting_settings')) {
        return;
    }

    // Retrieve and sanitize form data
    $morning_from = sanitize_text_field($_POST['morning_from']);
    $morning_to = sanitize_text_field($_POST['morning_to']);
    $evening_from = sanitize_text_field($_POST['evening_from']);
    $evening_to = sanitize_text_field($_POST['evening_to']);
    $selected_users = isset($_POST['users']) ? array_map('intval', $_POST['users']) : array();

    // Insert data into the table for each selected user and each meeting type
    $table_name = $wpdb->prefix . 'scrum_meetings';
    foreach ($selected_users as $user_id) {
        // Insert morning meeting
        $wpdb->insert(
            $table_name,
            array(
                'submission_date' => date('Y-m-d'),
                'meeting_type' => 'morning',
                'meeting_from' => $morning_from,
                'meeting_to' => $morning_to,
                'userid' => $user_id,
                'status' => null
            )
        );

        // Insert evening meeting
        $wpdb->insert(
            $table_name,
            array(
                'submission_date' => date('Y-m-d'),
                'meeting_type' => 'evening',
                'meeting_from' => $evening_from,
                'meeting_to' => $evening_to,
                'userid' => $user_id,
                'status' => null
            )
        );
    }

    // Redirect back to the settings page after saving
    wp_redirect(admin_url('admin.php?page=scrum-meetings'));
    exit;
}

// Settings page function
function scrum_meeting_set_meetings_page() {
    ?>
    <div class="wrap">
        <h1>Create Scrum Meeting</h1>
        <div class="scrum-meeting-container">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('save_scrum_meeting_settings'); ?>
                <div class="scrum-meeting-time">
                    <h2>Morning Meeting</h2>
                    <div class="time-selection-from">
                        <input type="time" required class="time-input" name="morning_from" id="morning_from">
                    </div>
                    <div class="time-selection-to">
                        <input type="time" required class="time-input" name="morning_to" id="morning_to">
                    </div>
                </div>
                <div class="scrum-meeting-time">
                    <h2>Evening Meeting</h2>
                    <div class="time-selection-from">
                        <input type="time" required class="time-input" name="evening_from" id="evening_from">
                    </div>
                    <div class="time-selection-to">
                        <input type="time" required class="time-input" name="evening_to" id="evening_to">
                    </div>
                </div>
                <div class="scrum-meeting-assign">
                    <h2>Assign to</h2>
                    <select class="user-select" required name="users[]" multiple>
                        <?php 
                        $users = get_users();
                        foreach($users as $user) { ?>
                            <option value="<?php echo $user->ID; ?>"><?php echo $user->first_name . ' ' . $user->last_name; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <input type="hidden" name="action" value="save_scrum_meeting_settings">
                <input type="submit" value="Save Settings" class="button-primary">
            </form>
        </div>
    </div>
    <?php
}

function scrum_meeting_settings_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';

    // Get all users
    $users = get_users();

    // Get all dates for the current month excluding Saturdays and Sundays
    $start_date = date('Y-m-01');
    $end_date = date('Y-m-t');
    $dates = array();
    $current_date = $start_date;
    while (strtotime($current_date) <= strtotime($end_date)) {
        // Check if the current date is not Saturday or Sunday
        if (date('N', strtotime($current_date)) < 6) {
            $dates[] = $current_date;
        }
        $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
    }

    // Get all scrum meeting records for the current month
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE submission_date BETWEEN %s AND %s",
        $start_date, $end_date
    ));

    // Organize results by user and date
    $attendance_data = array();
    foreach ($results as $row) {
        $attendance_data[$row->userid][$row->submission_date][$row->meeting_type] = array(
            'status' => $row->status,
            'meeting_from' => $row->meeting_from,
            'meeting_to' => $row->meeting_to
        );
    }

    ?>
    <div class="wrap">
        <div class="scrum-meeting-header">
            <h1>Scrum Meetings</h1>
            <div class="filter-container">
                <input type="month" id="filter_month_year" value="<?php echo date('Y-m'); ?>">
                <button id="apply_filter">Apply Filter</button>
            </div>
        </div>
        <div class="scrum-meeting-table-container">
            <table class="scrum-meeitng">
                <tr>
                    <th></th>
                    <?php foreach ($dates as $date) { ?>
                        <th><?php echo esc_html(date('d', strtotime($date))); ?></th>
                    <?php } ?>
                </tr>
                <?php foreach ($users as $user) { 
                    // Calculate attendance percentage
                    $total_meetings = count($dates) * 2; // morning and evening meetings
                    $attended_meetings = 0;
                    foreach ($dates as $date) {
                        if (isset($attendance_data[$user->ID][$date]['morning'])) {
                            $morning_status = intval($attendance_data[$user->ID][$date]['morning']['status']);
                            if ($morning_status > 0) {
                                $attended_meetings++;
                            }
                        }
                        if (isset($attendance_data[$user->ID][$date]['evening'])) {
                            $evening_status = intval($attendance_data[$user->ID][$date]['evening']['status']);
                            if ($evening_status > 0) {
                                $attended_meetings++;
                            }
                        }
                    }
                    $attendance_percentage = ($attended_meetings / $total_meetings) * 100;
                    $status_class = $attendance_percentage >= 80 ? 'good' : 'bad';
                ?>
                    <tr>
                        <td class="profile">
                            <img src="<?php echo esc_url(get_avatar_url($user->ID)); ?>" alt="Profile">
                            <span><?php echo esc_html($attended_meetings . ' / ' . $total_meetings); ?> <span class="status <?php echo esc_attr($status_class); ?>"><?php echo esc_html(round($attendance_percentage) . '%'); ?></span></span>
                        </td>
                        <?php foreach ($dates as $date) { 
                            $morning_status = isset($attendance_data[$user->ID][$date]['morning']) ? intval($attendance_data[$user->ID][$date]['morning']['status']) : null;
                            $morning_from = isset($attendance_data[$user->ID][$date]['morning']) ? $attendance_data[$user->ID][$date]['morning']['meeting_from'] : null;
                            $morning_to = isset($attendance_data[$user->ID][$date]['morning']) ? $attendance_data[$user->ID][$date]['morning']['meeting_to'] : null;

                            $evening_status = isset($attendance_data[$user->ID][$date]['evening']) ? intval($attendance_data[$user->ID][$date]['evening']['status']) : null;
                            $evening_from = isset($attendance_data[$user->ID][$date]['evening']) ? $attendance_data[$user->ID][$date]['evening']['meeting_from'] : null;
                            $evening_to = isset($attendance_data[$user->ID][$date]['evening']) ? $attendance_data[$user->ID][$date]['evening']['meeting_to'] : null;
                        ?>
                            <td class="attendance">
                                <div class="attendance-cell">
                                    <span class="<?php echo get_attendance_color_class($morning_status); ?>"></span>
                                    <span class="<?php echo get_attendance_color_class($evening_status); ?>"></span>
                                    <div class="modal" id="modal-<?php echo $user->ID . '-' . $date; ?>">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <span class="close" data-modal-id="modal-<?php echo $user->ID . '-' . $date; ?>">&times;</span>
                                                <p><?php echo esc_html(date('jS M Y', strtotime($date))); ?></p>
                                            </div>
                                            <div class="modal-body">
                                                <div class="modal-body-content">
                                                    <div class="modal-profile">
                                                        <img src="<?php echo esc_url(get_avatar_url($user->ID)); ?>" alt="Profile">
                                                    </div>
                                                    <div class="meeting-details">
                                                        <div class="meeting-detail">
                                                            <span class="status-circle <?php echo get_attendance_color_class($morning_status); ?>"></span>
                                                            <span>
                                                                <?php
                                                                if ($morning_status === 1) {
                                                                    echo esc_html($morning_from) . ' - without WebCam';
                                                                } elseif ($morning_status === 2) {
                                                                    echo esc_html($morning_from) . ' - with WebCam';
                                                                } elseif ($morning_status === null) {
                                                                    echo 'No Meeting';
                                                                } else {
                                                                    echo 'Not Attended';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                        <div class="meeting-detail">
                                                            <span class="status-circle <?php echo get_attendance_color_class($evening_status); ?>"></span>
                                                            <span>
                                                                <?php
                                                                if ($evening_status === 1) {
                                                                    echo esc_html($evening_from) . ' - without WebCam';
                                                                } elseif ($evening_status === 2) {
                                                                    echo esc_html($evening_from) . ' - with WebCam';
                                                                } elseif ($evening_status === null) {
                                                                    echo 'No Meeting';
                                                                } else {
                                                                    echo 'Not Attended';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        <?php } ?>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
    <?php
}



// PHP function to handle AJAX request
add_action('wp_ajax_filter_scrum_meetings', 'filter_scrum_meetings');
add_action('wp_ajax_nopriv_filter_scrum_meetings', 'filter_scrum_meetings');

function filter_scrum_meetings() {
    // Retrieve month and year from AJAX request
    $monthYear = $_POST['monthYear'];

    // Split month and year
    list($year, $month) = explode('-', $monthYear);

    // Calculate start and end date for the selected month
    $start_date = date('Y-m-01', strtotime("$year-$month-01"));
    $end_date = date('Y-m-t', strtotime("$year-$month-01"));

    // Get all users
    $users = get_users();

    // Get all dates for the selected month excluding Saturdays and Sundays
    $dates = array();
    $current_date = $start_date;
    while (strtotime($current_date) <= strtotime($end_date)) {
        // Check if the current date is not Saturday or Sunday
        if (date('N', strtotime($current_date)) < 6) {
            $dates[] = $current_date;
        }
        $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
    }

    // Get all scrum meeting records for the selected month
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE submission_date BETWEEN %s AND %s",
        $start_date, $end_date
    ));

    // Organize results by user and date
    $attendance_data = array();
    foreach ($results as $row) {
        $attendance_data[$row->userid][$row->submission_date][$row->meeting_type] = array(
            'status' => $row->status,
            'meeting_from' => $row->meeting_from,
            'meeting_to' => $row->meeting_to
        );
    }

    // Construct the table HTML with the respective values
    $table_html = '<table>';
    $table_html .= '<tr><th></th>';
    foreach ($dates as $date) {
        $table_html .= '<th>' . esc_html(date('d', strtotime($date))) . '</th>';
    }
    $table_html .= '</tr>';

    foreach ($users as $user) {
        // Calculate attendance percentage
        $attended_meetings = 0;
        foreach ($dates as $date) {
            if (isset($attendance_data[$user->ID][$date]['morning'])) {
                $morning_status = intval($attendance_data[$user->ID][$date]['morning']['status']);
                if ($morning_status > 0) {
                    $attended_meetings++;
                }
            }
            if (isset($attendance_data[$user->ID][$date]['evening'])) {
                $evening_status = intval($attendance_data[$user->ID][$date]['evening']['status']);
                if ($evening_status > 0) {
                    $attended_meetings++;
                }
            }
        }
        $total_meetings = count($dates) * 2; // morning and evening meetings
        $attendance_percentage = ($attended_meetings / $total_meetings) * 100;
        $status_class = $attendance_percentage >= 80 ? 'good' : 'bad';

        $table_html .= '<tr>';
        $table_html .= '<td class="profile">';
        $table_html .= '<img src="' . esc_url(get_avatar_url($user->ID)) . '" alt="Profile">';
        $table_html .= '<span>' . esc_html($attended_meetings . ' / ' . $total_meetings) . ' <span class="status ' . esc_attr($status_class) . '">' . esc_html(round($attendance_percentage) . '%') . '</span></span>';
        $table_html .= '</td>';
        foreach ($dates as $date) {
            $morning_status = isset($attendance_data[$user->ID][$date]['morning']) ? intval($attendance_data[$user->ID][$date]['morning']['status']) : null;
            $morning_from = isset($attendance_data[$user->ID][$date]['morning']) ? $attendance_data[$user->ID][$date]['morning']['meeting_from'] : null;
            $morning_to = isset($attendance_data[$user->ID][$date]['morning']) ? $attendance_data[$user->ID][$date]['morning']['meeting_to'] : null;

            $evening_status = isset($attendance_data[$user->ID][$date]['evening']) ? intval($attendance_data[$user->ID][$date]['evening']['status']) : null;
            $evening_from = isset($attendance_data[$user->ID][$date]['evening']) ? $attendance_data[$user->ID][$date]['evening']['meeting_from'] : null;
            $evening_to = isset($attendance_data[$user->ID][$date]['evening']) ? $attendance_data[$user->ID][$date]['evening']['meeting_to'] : null;

            $table_html .= '<td class="attendance">';
            $table_html .= '<div class="attendance-cell">';
            $table_html .= '<span class="' . get_attendance_color_class($morning_status) . '"></span>';
            $table_html .= '<span class="' . get_attendance_color_class($evening_status) . '"></span>';
            $table_html .= '<div class="modal" id="modal-' . $user->ID . '-' . $date . '">';
            $table_html .= '<div class="modal-content">';
            $table_html .= '<div class="modal-header">';
            $table_html .= '<span class="close" data-modal-id="modal-' . $user->ID . '-' . $date . '">&times;</span>';
            $table_html .= '<p>' . esc_html(date('jS M Y', strtotime($date))) . '</p>';
            $table_html .= '</div>';
            $table_html .= '<div class="modal-body">';
            $table_html .= '<div class="modal-body-content">';
            $table_html .= '<div class="modal-profile">';
            $table_html .= '<img src="' . esc_url(get_avatar_url($user->ID)) . '" alt="Profile">';
            $table_html .= '</div>';
            $table_html .= '<div class="meeting-details">';
            $table_html .= '<div class="meeting-detail">';
            $table_html .= '<span class="status-circle ' . get_attendance_color_class($morning_status) . '"></span>';
            $table_html .= '<span>';
            if ($morning_status === 1) {
                $table_html .= esc_html($morning_from) . ' - without WebCam';
            } elseif ($morning_status === 2) {
                $table_html .= esc_html($morning_from) . ' - with WebCam';
            } elseif ($morning_status === null) {
                $table_html .= 'No Meeting';
            } else {
                $table_html .= 'Not Attended';
            }
            $table_html .= '</span>';
            $table_html .= '</div>';
            $table_html .= '<div class="meeting-detail">';
            $table_html .= '<span class="status-circle ' . get_attendance_color_class($evening_status) . '"></span>';
            $table_html .= '<span>';
            if ($evening_status === 1) {
                $table_html .= esc_html($evening_from) . ' - without WebCam';
            } elseif ($evening_status === 2) {
                $table_html .= esc_html($evening_from) . ' - with WebCam';
            } elseif ($evening_status === null) {
                $table_html .= 'No Meeting';
            } else {
                $table_html .= 'Not Attended';
            }
            $table_html .= '</span>';
            $table_html .= '</div>';
            $table_html .= '</div>';
            $table_html .= '</div>';
            $table_html .= '</div>';
            $table_html .= '</div>';
            $table_html .= '</div>';
            $table_html .= '</td>';
        }
        $table_html .= '</tr>';
    }

    $table_html .= '</table>';

    // Echo the HTML content
    echo $table_html;

    // Exit to prevent WordPress from returning default 0
    exit;
}


function get_attendance_color_class($status) {
    if ($status === 2) {
        return 'green'; // Attended with webcam
    } elseif ($status === 1) {
        return 'orange'; // Attended without webcam
    }elseif ($status === 0) {
        return 'black'; // Not attended
    }else {
        return 'grey'; // No Meeting
    }
}

// Shortcode function for morning meeting
function morning_meeting_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';
    $current_user_id = get_current_user_id();
    $current_time = current_time('H:i:s');

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE submission_date = %s AND meeting_type = 'morning' AND userid = %d",
        date('Y-m-d'), $current_user_id
    ));

    ob_start();
    $call_scheduled = false;
    if ($results) {
        foreach ($results as $row) {
            if ($row->status !== null) {
                echo '<div class="card"><div class="confirmation">Today\'s Morning Meeting attended ' 
                    . ($row->status == 2 ? 'with Webcam' : 'without Webcam') 
                    . ' - Logged on ' . date('g:i A', strtotime($row->log_time)) . '</div></div>';
                $call_scheduled = true;
                break; // Stop checking further meetings once attended meeting is found
            }

            if ($current_time < $row->meeting_from) {
                $time_diff = strtotime($row->meeting_from) - strtotime($current_time);
                $hours_remaining = floor($time_diff / 3600);
                $minutes_remaining = floor(($time_diff % 3600) / 60);
                echo "<div class='card'><div class='confirmation'>Wait for Morning Meeting. It will start in $hours_remaining hrs $minutes_remaining mins</div></div>";
                $call_scheduled = true;
                break; // Stop checking further meetings once upcoming meeting is found
            }

            $morning_start = date('H:i:s', strtotime($row->meeting_from));
            $morning_end = date('H:i:s', strtotime($row->meeting_to . ' +10 minutes'));

            if ($current_time >= $morning_start && $current_time <= $morning_end) {
                $time_diff = strtotime($morning_end) - strtotime($current_time);
                $time_remaining = floor($time_diff / 60);
                ?>
                <div class="cardbody" data-meeting-id="<?php echo esc_attr($row->id); ?>">
                    <div class="card">
                        <div class="date"><?php echo esc_html(date('jS F Y', strtotime($row->submission_date))); ?></div>
                        <div class="title">
                            <img src="<?php echo esc_url(get_avatar_url($current_user_id)); ?>" alt="Profile">
                            <div style="margin-left: 10px;">Morning Meeting</div>
                        </div>
                        <div class="time"><?php echo date('g:i A', strtotime($row->meeting_from)); ?> - <?php echo date('g:i A', strtotime($row->meeting_to)); ?></div>
                        <div class="buttons">
                            <div class="button" onclick="updateMeetingStatus(<?php echo esc_js($row->id); ?>, 1)">Attended</div>
                            <div class="button" onclick="updateMeetingStatus(<?php echo esc_js($row->id); ?>, 2)">Attended with Webcam</div>
                        </div>
                        <div class="footer"><?php echo $time_remaining . ' MIN LEFT'; ?></div>
                    </div>
                </div>
                <?php
                $call_scheduled = true;
                break; // Stop checking further meetings once current meeting is found
            }
        }
    }

    if (!$call_scheduled) {
        echo "<div class='card'><div class='confirmation'>No call scheduled for today morning</div></div>";
    }

    // Add the snackbar HTML
    echo '<div id="snackbar">Scrum Entry has been logged</div>';

    return ob_get_clean();
}
add_shortcode('morning_meeting_shortcode', 'morning_meeting_shortcode');

// Shortcode function for evening meeting
function evening_meeting_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';
    $current_user_id = get_current_user_id();
    $current_time = current_time('H:i:s');

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE submission_date = %s AND meeting_type = 'evening' AND userid = %d",
        date('Y-m-d'), $current_user_id
    ));

    ob_start();
    $call_scheduled = false;
    if ($results) {
        foreach ($results as $row) {
            if ($row->status !== null) {
                echo '<div class="card"><div class="confirmation">Today\'s Evening Meeting attended ' 
                    . ($row->status == 2 ? 'with Webcam' : 'without Webcam') 
                    . ' - Logged on ' . date('g:i A', strtotime($row->log_time)) . '</div></div>';
                $call_scheduled = true;
                break; // Stop checking further meetings once attended meeting is found
            }

            if ($current_time < $row->meeting_from) {
                $time_diff = strtotime($row->meeting_from) - strtotime($current_time);
                $hours_remaining = floor($time_diff / 3600);
                $minutes_remaining = floor(($time_diff % 3600) / 60);
                echo "<div class='card'><div class='confirmation'>Wait for Evening Meeting. It will start in $hours_remaining hrs $minutes_remaining mins</div></div>";
                $call_scheduled = true;
                break; // Stop checking further meetings once upcoming meeting is found
            }

            $evening_start = date('H:i:s', strtotime($row->meeting_from));
            $evening_end = date('H:i:s', strtotime($row->meeting_to . ' +10 minutes'));

            if ($current_time >= $evening_start && $current_time <= $evening_end) {
                $time_diff = strtotime($evening_end) - strtotime($current_time);
                $time_remaining = floor($time_diff / 60);
                ?>
                <div class="cardbody" data-meeting-id="<?php echo esc_attr($row->id); ?>">
                    <div class="card">
                        <div class="date"><?php echo esc_html($row->submission_date); ?></div>
                        <div class="title">
                            <img src="<?php echo esc_url(get_avatar_url($current_user_id)); ?>" alt="Profile">
                            <div style="margin-left: 10px;">Evening Meeting</div>
                        </div>
                        <div class="time"><?php echo date('g:i A', strtotime($row->meeting_from)); ?> - <?php echo date('g:i A', strtotime($row->meeting_to)); ?></div>
                        <div class="buttons">
                            <div class="button" onclick="updateMeetingStatus(<?php echo esc_js($row->id); ?>, 1)">Attended</div>
                            <div class="button" onclick="updateMeetingStatus(<?php echo esc_js($row->id); ?>, 2)">Attended with Webcam</div>
                        </div>
                        <div class="footer"><?php echo $time_remaining . ' MIN LEFT'; ?></div>
                    </div>
                </div>
                <?php
                $call_scheduled = true;
                break; // Stop checking further meetings once current meeting is found
            }
        }
    }

    if (!$call_scheduled) {
        echo "<div class='card'><div class='confirmation'>No call scheduled for today evening</div></div>";
    }

    // Add the snackbar HTML
    echo '<div id="snackbar">Scrum Entry has been logged</div>';
    return ob_get_clean();
}
add_shortcode('evening_meeting_shortcode', 'evening_meeting_shortcode');

// Register a new widget area
function register_scrum_call_widget_area() {
    register_sidebar( array(
        'name'          => 'Scrum Call',
        'id'            => 'scrum_call',
        'before_widget' => '<div class="widget scrum-call-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'register_scrum_call_widget_area' );

// Combined shortcode for displaying morning and evening meetings
function combined_scrum_meetings_shortcode() {
    ob_start();

    echo '<div class="scrum-meetings-widget">';

    // Morning Meetings Section
    echo '<div class="scrum-meetings-section">';
    echo '<h2>Morning Meeting</h2>';
    echo do_shortcode('[morning_meeting_shortcode]');
    echo '</div>';

    // Evening Meetings Section
    echo '<div class="scrum-meetings-section">';
    echo '<h2>Evening Meeting</h2>';
    echo do_shortcode('[evening_meeting_shortcode]');
    echo '</div>';

    echo '</div>';

    return ob_get_clean();
}
add_shortcode('combined_scrum_meetings', 'combined_scrum_meetings_shortcode');

// Function to add the custom dashboard widget
function add_scrum_call_dashboard_widget() {
    wp_add_dashboard_widget(
        'scrum_call_dashboard_widget', // Widget slug
        'Scrum Call',                  // Title
        'display_scrum_call_dashboard_widget' // Display function
    );
}
add_action( 'wp_dashboard_setup', 'add_scrum_call_dashboard_widget' );  

// Function to display the Scrum Call widget area on the dashboard
function display_scrum_call_dashboard_widget() {
    if ( is_active_sidebar( 'scrum_call' ) ) {
        dynamic_sidebar( 'scrum_call' );
    } else {
        echo 'No widgets added to the Scrum Call widget area.';
    }
}

function update_meeting_status() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'scrum_meetings';

    // Check nonce for security
    check_ajax_referer('update_meeting_status_nonce', 'security');

    $meeting_id = intval($_POST['meeting_id']);
    $status = intval($_POST['status']);
    $log_time = sanitize_text_field($_POST['log_time']); // Directly get current time

    // Update the row
    $updated = $wpdb->update(
        $table_name,
        array('status' => $status, 'log_time' => $log_time), // Update both status and log_time
        array('id' => $meeting_id),
        array('%d', '%s'), // Status is an integer, log_time is a string (datetime)
        array('%d')
    );

    if ($updated !== false) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
}
add_action('wp_ajax_update_meeting_status', 'update_meeting_status');
add_action('wp_ajax_nopriv_update_meeting_status', 'update_meeting_status');



